create
    definer = root@localhost procedure GetMapByName(IN mapName varchar(255))
BEGIN
    SELECT line FROM map WHERE name1 = mapName;
END;

